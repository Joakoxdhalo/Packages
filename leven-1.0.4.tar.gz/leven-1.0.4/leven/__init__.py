from ._levenshtein import levenshtein

__version__ = '1.0.4'
